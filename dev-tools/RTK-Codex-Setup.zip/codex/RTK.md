# RTK - Rust Token Killer (Codex CLI)

**Usage**: Token-optimized CLI proxy for shell commands.

## Rule

Use `/root/.local/bin/rtk` (shown below as `rtk`). Prefer RTK for supported development commands when condensed output is sufficient, for example `rtk git status` and supported build/test commands. Use native commands for unsupported operations, exact source or configuration reads, machine-parsed output, security review, and when important details may be filtered. Reach first for `rg` / `rg --files` for text and file searches. Read full failure logs when necessary; do not treat filtered or empty output as proof of success.

RTK must preserve the original operation and its authorization requirements. Never use RTK or `rtk proxy` to bypass tool, network, sandbox, or approval restrictions. Keep telemetry disabled. This installation applies to the current execution environment; its presence in new environments must be checked.

Examples:

```bash
rtk git status
rtk cargo test
rtk npm run build
rtk pytest -q
```

## Meta Commands

```bash
rtk gain            # Token savings analytics
rtk gain --history  # Recent command savings history
rtk proxy <cmd>     # Run raw command without filtering
```

## Verification

```bash
rtk --version
rtk gain
which rtk
```
