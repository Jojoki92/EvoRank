## RTK output compression

RTK is installed at `/root/.local/bin/rtk`; use this absolute executable path because it is not on the default PATH. Before using it, read `/root/.codex/RTK.md`. Prefer RTK for supported development commands when compact output is sufficient. Keep native commands for exact reads, machine-parsed output, unsupported commands, and critical verification. All existing permissions and approval rules continue to apply. Keep telemetry disabled. Check availability again in a new execution environment.

@/root/.codex/RTK.md
