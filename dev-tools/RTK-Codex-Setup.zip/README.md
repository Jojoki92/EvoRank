# RTK für Codex – Einrichtung vom 6. September 2026

RTK 0.48.0 wurde in der aktuellen Linux-Arbeitsumgebung installiert, für Codex eingerichtet und geprüft.

## Aktueller Zustand

- Programm: /root/.local/bin/rtk (absoluten Pfad verwenden; nicht im Standard-PATH).
- Codex-Anweisungen: /root/.codex/AGENTS.md und /root/.codex/RTK.md.
- RTK-Konfiguration: /root/.config/rtk/config.toml.
- Telemetrie ist deaktiviert.
- Verwendung über ausdrückliche RTK-Befehle und Codex-Anweisungen; kein automatischer Claude-Hook.
- Für exakte Dateiinhalte, nicht unterstützte Befehle und wichtige Prüfungen bleiben native Befehle vorgesehen.

## Prüfung

- Veröffentlichte SHA-256-Prüfsumme des Download-Archivs stimmt überein.
- Das ursprüngliche Installationsskript scheiterte beim Übernehmen fremder Dateieigentümer im Container. Die reguläre Programmdatei wurde anschließend aus demselben erneut geprüften Archiv installiert, ohne die fremden Eigentümer zu übernehmen.
- Versionsaufruf und Codex-Konfigurationsprüfung erfolgreich.
- Ein eigens angelegtes Testprojekt lieferte für git status 647 Zeichen mit Git und 387 mit RTK. Das ist nur ein Funktionstest, keine Prognose für andere Projekte oder Gesamtkosten.
- Ein absichtlicher Fehler behielt seine Fehlermeldung und Exit-Code 7.

## Geltungsbereich und Wiederverwendung

Dieses Paket sichert die Einrichtung, aktiviert sie aber nicht automatisch in neuen Chats oder auf einem anderen Computer. Die enthaltene Binärdatei ist für Linux x86_64 bestimmt. In einer neuen Arbeitsumgebung zuerst die Verfügbarkeit prüfen; erforderliche Dateien gezielt wiederherstellen und Codex-Anweisungen mit vorhandenen Anweisungen zusammenführen. Bestehende Konfigurationen nicht ungeprüft überschreiben. Die absoluten Pfade müssen zur jeweiligen Umgebung passen.

RTK verkürzt bestimmte Terminalausgaben bei Programmierarbeiten. Daraus folgt keine bestimmte Erhöhung des ChatGPT-Nutzungslimits oder eine bestimmte Einsparung bei einem Abonnement.

## Quellen

- RTK: https://github.com/rtk-ai/rtk
- Verwendete Veröffentlichung: https://github.com/rtk-ai/rtk/releases/tag/v0.48.0
- Installationsskript: https://raw.githubusercontent.com/rtk-ai/rtk/refs/heads/master/install.sh
- Codex-Anweisungen: https://learn.chatgpt.com/docs/agent-configuration/agents-md

Die RTK-Binärdatei ist unverändert. Die beiliegenden Codex-Anweisungen wurden an diese Arbeitsumgebung angepasst. Die Lizenz liegt unter upstream/LICENSE.
